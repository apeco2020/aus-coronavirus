# popSim

NOTE: Development has moved to github.com/cjbattey/driftR. Of course there was another program named popSim. 

population genetic simulations inspired by popG (http://evolution.gs.washington.edu/popgen/popg.html)

To run locally: open Rstudio, download all .R files into your current working directory, 
load Shiny ("library(shiny)"), and run "runApp()". 

If it throws an error you may need to install one of the required
packages (try "install.packages("nameofpackage")).
