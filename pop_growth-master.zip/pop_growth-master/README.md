# pop_growth
R code for population simulation based on population structure

 - Uses specie structure and stage-based cicle probabilities

## author: Adrià Masip
